#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char string[50],stringCopia[50];
    int qtvogais,c,lente;
    qtvogais=0;
    
    printf("digite uma palavra");
    scanf("%s",string);
    strcpy(stringCopia,string);
    
    lente=strlen(string);
    
    for(c=0;c<lente;c++){
        stringCopia[c]=tolower(stringCopia[c]);
        if (stringCopia[c]=='a'){
            string[c]='A';
        }
        if (stringCopia[c]=='e'){
            string[c]='E';
        }
        if (stringCopia[c]=='i'){
            string[c]='I';
        }
        if (stringCopia[c]=='o'){
            string[c]='O';
        }
        if (stringCopia[c]=='u'){
            string[c]='U';
        }
        printf("%s \n",string);
    }
    return 0;
}

